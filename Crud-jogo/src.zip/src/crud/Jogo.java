package crud;

import java.time.LocalDate;

public class Jogo {
    private int id;
    private String nome;
    private LocalDate dataLancamento;
    private double preco;
    private String genero;
    private int idDesenvolvedora;

    public Jogo(int id, String nome, LocalDate dataLancamento, double preco, String genero, int idDesenvolvedora) {
        if (preco <= 0) {
            throw new IllegalArgumentException("O pre�o deve ser maior que zero.");
        }
        if (genero == null || genero.isEmpty()) {
            throw new IllegalArgumentException("O g�nero do jogo deve ser definido.");
        }
        this.id = id;
        this.nome = nome;
        this.dataLancamento = dataLancamento;
        this.preco = preco;
        this.genero = genero;
        this.idDesenvolvedora = idDesenvolvedora;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public LocalDate getDataLancamento() {
        return dataLancamento;
    }

    public double getPreco() {
        return preco;
    }

    public String getGenero() {
        return genero;
    }

    public int getIdDesenvolvedora() {
        return idDesenvolvedora;
    }

	@Override
	public String toString() {
		return "Jogo Id: " + id + ", Nome: " + nome + ", Data de Lancamento: " + dataLancamento + ", Preco: " + preco
				+ ", Genero: " + genero + ", Id da Desenvolvedora: " + idDesenvolvedora + "]";
	}
}
