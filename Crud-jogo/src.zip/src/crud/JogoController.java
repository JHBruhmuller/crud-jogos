package crud;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class JogoController {
    private JogoService jogoService = new JogoService();
    private Scanner scanner = new Scanner(System.in);

    public void iniciar() {
        int opcao;
        do {
            System.out.println("\nEscolha uma opera��o: ");
            System.out.println("1 - Adicionar Jogo");
            System.out.println("2 - Buscar Jogo");
            System.out.println("3 - Atualizar Jogo");
            System.out.println("4 - Remover Jogo");
            System.out.println("5 - Listar Jogos");
            System.out.println("0 - Sair");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1 -> adicionarJogo();
                case 2 -> buscarJogo();
                case 3 -> atualizarJogo();
                case 4 -> removerJogo();
                case 5 -> listarJogos();
                case 0 -> System.out.println("Saindo...");
                default -> System.out.println("Op��o inv�lida!");
            }
        } while (opcao != 0);
    }

    private void adicionarJogo() {
        System.out.print("ID: ");
        int id = scanner.nextInt();
        System.out.print("Nome: ");
        scanner.nextLine();
        String nome = scanner.nextLine();
        System.out.print("Data de Lan�amento (yyyy-MM-dd): ");
        LocalDate dataLancamento = LocalDate.parse(scanner.nextLine());
        System.out.print("Pre�o: ");
        double preco = scanner.nextDouble();
        System.out.print("G�nero: ");
        scanner.nextLine();
        String genero = scanner.nextLine();
        System.out.print("ID da Desenvolvedora: ");
        int idDesenvolvedora = scanner.nextInt();

        Jogo jogo = new Jogo(id, nome, dataLancamento, preco, genero, idDesenvolvedora);
        jogoService.adicionarJogo(jogo);
        System.out.println("Jogo adicionado com sucesso!");
    }

    private void buscarJogo() {
        System.out.print("ID do Jogo: ");
        int id = scanner.nextInt();
        Jogo jogo = jogoService.buscarJogo(id);
        if (jogo != null) {
            System.out.println(jogo);
        } else {
            System.out.println("Jogo n�o encontrado.");
        }
    }

    private void atualizarJogo() {
        System.out.print("ID do Jogo: ");
        int id = scanner.nextInt();
        System.out.print("Novo Nome: ");
        scanner.nextLine();
        String nome = scanner.nextLine();
        System.out.print("Nova Data de Lan�amento (yyyy-MM-dd): ");
        LocalDate dataLancamento = LocalDate.parse(scanner.nextLine());
        System.out.print("Novo Pre�o: ");
        double preco = scanner.nextDouble();
        System.out.print("Novo G�nero: ");
        scanner.nextLine();
        String genero = scanner.nextLine();
        System.out.print("ID da Desenvolvedora: ");
        int idDesenvolvedora = scanner.nextInt();

        Jogo jogo = new Jogo(id, nome, dataLancamento, preco, genero, idDesenvolvedora);
        jogoService.atualizarJogo(jogo);
        System.out.println("Jogo atualizado com sucesso!");
    }

    private void removerJogo() {
        System.out.print("ID do Jogo: ");
        int id = scanner.nextInt();
        jogoService.removerJogo(id);
        System.out.println("Jogo removido com sucesso!");
    }

    private void listarJogos() {
        List<Jogo> jogos = jogoService.listarJogos();
        if (jogos.isEmpty()) {
            System.out.println("Nenhum jogo encontrado.");
        } else {
            jogos.forEach(System.out::println);
        }
    }
}
