package crud;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class DesenvolvedoraController {
    private DesenvolvedoraService desenvolvedoraService = new DesenvolvedoraService();
    private Scanner scanner = new Scanner(System.in);

    public void iniciar() {
        int opcao;
        do {
            System.out.println("\nEscolha uma opera��o: ");
            System.out.println("1 - Adicionar Desenvolvedora");
            System.out.println("2 - Buscar Desenvolvedora");
            System.out.println("3 - Atualizar Desenvolvedora");
            System.out.println("4 - Remover Desenvolvedora");
            System.out.println("5 - Listar Desenvolvedoras");
            System.out.println("0 - Sair");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1 -> adicionarDesenvolvedora();
                case 2 -> buscarDesenvolvedora();
                case 3 -> atualizarDesenvolvedora();
                case 4 -> removerDesenvolvedora();
                case 5 -> listarDesenvolvedoras();
                case 0 -> System.out.println("Saindo...");
                default -> System.out.println("Op��o inv�lida!");
            }
        } while (opcao != 0);
    }

    private void adicionarDesenvolvedora() {
        System.out.print("ID: ");
        int id = scanner.nextInt();
        System.out.print("Nome: ");
        scanner.nextLine();
        String nome = scanner.nextLine();
        System.out.print("Data de Funda��o (yyyy-MM-dd): ");
        LocalDate dataFundacao = LocalDate.parse(scanner.nextLine());

        Desenvolvedora desenvolvedora = new Desenvolvedora(id, nome, dataFundacao);
        desenvolvedoraService.adicionarDesenvolvedora(desenvolvedora);
        System.out.println("Desenvolvedora adicionada com sucesso!");
    }

    private void buscarDesenvolvedora() {
        System.out.print("ID: ");
        int id = scanner.nextInt();
        Desenvolvedora desenvolvedora = desenvolvedoraService.buscarDesenvolvedora(id);
        if (desenvolvedora != null) {
            System.out.println(desenvolvedora);
        } else {
            System.out.println("Desenvolvedora n�o encontrada.");
        }
    }

    private void atualizarDesenvolvedora() {
        System.out.print("ID: ");
        int id = scanner.nextInt();
        System.out.print("Novo Nome: ");
        scanner.nextLine();
        String nome = scanner.nextLine();
        System.out.print("Nova Data de Funda��o (yyyy-MM-dd): ");
        LocalDate dataFundacao = LocalDate.parse(scanner.nextLine());

        Desenvolvedora desenvolvedora = new Desenvolvedora(id, nome, dataFundacao);
        desenvolvedoraService.atualizarDesenvolvedora(desenvolvedora);
        System.out.println("Desenvolvedora atualizada com sucesso!");
    }

    private void removerDesenvolvedora() {
        System.out.print("ID: ");
        int id = scanner.nextInt();
        desenvolvedoraService.removerDesenvolvedora(id);
        System.out.println("Desenvolvedora removida com sucesso!");
    }

    private void listarDesenvolvedoras() {
        List<Desenvolvedora> desenvolvedoras = desenvolvedoraService.listarDesenvolvedoras();
        if (desenvolvedoras.isEmpty()) {
            System.out.println("Nenhuma desenvolvedora encontrada.");
        } else {
            desenvolvedoras.forEach(System.out::println);
        }
    }
}
